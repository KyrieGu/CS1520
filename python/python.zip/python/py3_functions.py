def say_hi():
	print("Hi!")

say_hi()
	
def shout(message="Hi"):
	print(message, "!", sep="")

shout()
shout("I love python")
shout(message="And keyword arguments")
