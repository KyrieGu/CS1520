#-------------------------------------------------------------------------------------
#models of onwer, customers and staffs used for database
#owner model
# class Owner(db.Model):
#     __tablename__ = 'Owner'
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(100))
#     password = db.Column(db.String(100))

#     def __init__(self):
# 	    self.username = "owner"
# 	    self.password = "pass"

#     def __repr__(self):
#         return '<Owner {}>'.format(repr(self.username))

#     def create_staff():
#         pass

# #cutomer model
# class Customer(db.Model):
#     __tablename__ = 'Customer'
#     id = db.Column(db.Integer, primary_key=True)
#     c_username = db.Column(db.String(100))
#     password = db.Column(db.String(100))
#     staff = db.Column(db.Integer, default = 1)

#     def __init__(self,name, password):
# 	    self.c_username = name
# 	    self.password = password

#     def __repr__(self):
#         return '<Customer {}>'.format(repr(self.c_username))

# #staff model
# class Staff(db.Model):
#     __tablename__ = 'Staff'
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(100))
#     password = db.Column(db.String(100))
#     staff = db.Column(db.Integer, default=0)

#     def __init__(self,name,password):
# 	    self.username = name
# 	    self.password = password

#     def __repr__(self):
#         return '<Staff {}>'.format(repr(self.username))


class User(db.Model):
    # id = id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), primary_key=True)
    password = db.Column(db.String(100))
    status = db.Column(db.String(100))

    # def __init__(self,name,password):
#     self.username = name
#     self.password = password

    def __repr__(self):
        return '<Staff {}>'.format(repr(self.username))


#This is task model
class Events(db.Model):
    # id = db.Column(db.Integer, primary_key=True)
    event = db.Column(db.String(200), nullable=False, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    staff = db.Column(db.String(100))
    schedule = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<Event %r>' % self.id
