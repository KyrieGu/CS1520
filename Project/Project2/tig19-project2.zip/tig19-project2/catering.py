from flask import *
from flask_sqlalchemy import *
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///catering.db'
app.secret_key = 'secret'
db = SQLAlchemy(app)

#-------------------------------------------------------------------------------------
#models of onwer, customers and staffs used for database 
class User(db.Model):
    # id = id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable = False, primary_key = True)
    password = db.Column(db.String(100))
    status = db.Column(db.String(100))
    login = db.Column(db.Boolean, default = False)

    # def __init__(self,name,password):
	#     self.username = name
	#     self.password = password

    def __repr__(self):
        return '<User {}>'.format(repr(self.username))


#This is task model
class Events(db.Model):
    # id = db.Column(db.Integer, primary_key=True)
    event = db.Column(db.String(200), nullable=False, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    staff = db.Column(db.String(100))
    schedule = db.Column(db.Integer,default = 0)

    def __repr__(self):
        return '<Event %r>' % self.event



#-------------------------------------------------------------------------------------


@app.cli.command('initdb')
def initdb_command():
    db.drop_all()
    db.create_all()
    owner = User(username = 'owner', password = 'pass', status = 'owner')
    db.session.add(owner)
    db.session.commit()
    return True


#handle error
@app.errorhandler(401)
def custom_401(error):
    return redirect(url_for('error_page'))

#for home page
@app.route("/")
def home():
    return redirect(url_for('login_page'))


#log in page
@app.route('/login', methods=['POST', 'GET'])
def login_page():
    if request.method == 'POST':
        
        user = request.form['username']
        password = request.form['password']
        current_user = User.query.get_or_404(user)
        current_user.login = True
        db.session.commit()
        #check user's status
        if(user == 'owner' and password == 'pass'):
            #user is owner
            return redirect(url_for('owner_page'))
        
        #check whether he is a staff
        elif(User.query.get_or_404(user).status == 'staff'):
            #User is staff
            return redirect(url_for('staff_page'))
        
        #check whether he is a customer
        elif(User.query.get_or_404(user).status == 'customer'):
            #User is customer
            return redirect(url_for('customer_page'))

        else:
            flash('No such account')
            return redirect(url_for('home'))
    
    else:
        users = User.query.order_by(User.username).all()
        return render_template('login.html',users = users)


@app.route('/logout')
def logout():
    user_to_logout = User.query.filter(User.login == True)
    
    try:
        user_to_logout.login = False
        db.session.commit()

    except:
        return "something is wrong"

    return redirect('/')


#owner page
@app.route('/owner')
def owner_page():
    
    events = Events.query.order_by(Events.date_created).all()
    
    if len(events) == 0:
        print('Nothing at all')
        flash('no events are scheduled')

    return render_template('owner.html', events = events)


#customer page
@app.route('/customer', methods=['POST', 'GET'])
def customer_page():

    if request.method == 'POST':
        event = request.form['event'] 

        #register user
        try:
            new_event = Events(event = event)
            db.session.add(new_event)
            db.session.commit()
            events = Events.query.order_by(Events.date_created).all()
            return render_template('customer.html', events = events)

        except:
            return render_template('customer.html')
    
    events = Events.query.order_by(Events.date_created).all()
    return render_template('customer.html', events = events)


#staff page
@app.route('/staff')
def staff_page():

    events = Events.query.order_by(Events.date_created).all()
    return render_template('staff.html', events=events)


@app.route('/error')
def error_page():
    return render_template('error.html')


@app.route('/register', methods=['POST', 'GET'])
def register_page():
    if request.method == 'POST':
        new_user = request.form['username']
        new_password = request.form['password']
        
        #register user
        try:
            new_user = User(username=new_user, password=new_password, status = 'customer')
            db.session.add(new_user)
            db.session.commit()
            return redirect('/')

        except:
            return 'There was an issue to add new user'
            
        return render_template('register.html')

    else:
        users = User.query.order_by(User.username).all()
        return render_template('register.html')


@app.route('/create_staff', methods = ['POST','GET'])
def create_staff():
    if request.method == 'POST':
        new_staff = request.form['username']
        new_password = request.form['password']

        #register user
        try:
            new_user = User(username=new_staff, password=new_password, status='staff')
            db.session.add(new_user)
            db.session.commit()
            return redirect('/')

        except:
            return 'There was an issue to add new user'

        return render_template('create_staff.html')

    else:
        users = User.query.order_by(User.username).all()
        return render_template('create_staff.html')



#-------------------------------------------------------------------------------------
@app.route('/delete/<string:user>')
def delete(user):
    user_to_delete = User.query.get_or_404(user)
    if(user_to_delete.username == 'owner'):
        return redirect('/')
    
    if(user_to_delete.username == None):
        return redirect('/')
    
    try:
        db.session.delete(user_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'There was a problem deleting that task'


@app.route('/cancel/<string:event>')
def cancel(event):
    event_to_delete = Events.query.get_or_404(event)

    try:
        db.session.delete(event_to_delete)
        db.session.commit()
        events = Events.query.order_by(Events.date_created).all()
        return render_template('customer.html', events=events)
    except:
        return 'There was a problem deleting that task'


@app.route('/sign_up/<string:event>')
def sign_up(event):
    event_to_sign = Events.query.get_or_404(event)
    sign_staff = User.query.filter(User.login == True and User.status == 'staff').first().username
    new_one = Events(event = event_to_sign.event, date_created = event_to_sign.date_created, staff = sign_staff,
                     schedule = event_to_sign.schedule + 1)

    try:
        db.session.delete(event_to_sign)
        db.session.commit()
        db.session.add(new_one)
        db.session.commit()

    except:
        # db.session.rollback()
        # db.session.flush()
        events = Events.query.order_by(Events.date_created).all()
        return redirect(url_for('staff_page',events = events))


    events = Events.query.order_by(Events.date_created).all()
    return redirect(url_for('staff_page', events=events))



#run the app
if __name__ == "__main__":
    app.run(debug=True)
