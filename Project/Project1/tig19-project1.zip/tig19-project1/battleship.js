
/*
Javascript for the battleship game
Tianrun Gu
Tig19@Pitt.edu
*/

//alphabet
var alpha = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

//ship names
var shipNames = {
    A: "A",
    B: "B",
    S: "S"
};

//game information
var gameover = false;
var turn = 0;       //0 indicates the first player, 1 indicates the second player
var hitCount = {
    A: 0,
    A_A: 0, //count for Aircraft
    A_B: 0, //count for battleship
    A_S: 0, //count for submarine

    B: 0,
    B_A: 0,
    B_B: 0,
    B_S: 0
};

// set grid rows and columns and the size of each square
var rows = 10;
var cols = 10;
var squareSize = 50;

// get the container element
var gameBoardContainer1 = document.getElementById("gameboard1");
var gameBoardContainer2 = document.getElementById("gameboard2");

//players' gamebaord, NOT UI but arrays
var p1_gameboard;
var p2_gameboard;


//player's target
var p1_target;      //player 1's target 
var p2_target;      //player 2's target

//turn switch
var turnSwitch = document.getElementById("")

//we only need top table to be listened
gameBoardContainer1.addEventListener("click", fire, false);

//generate the game board UI
gameBoardContainer1 = initialize(gameBoardContainer1, 1);
gameBoardContainer2 = initialize(gameBoardContainer2, 2);

//generate gameboard NOT UI
p1_gameboard = generateGameboard(p1_gameboard);
p2_gameboard = generateGameboard(p2_gameboard);

// Begining of the game
// get the first player's name & placement
var p1 = prompt("Please enter the first player's name");
while (!p1) {
    p1 = prompt("The name is not valid. please enter again");
}
var p1_placement = prompt("Please enter your placement");
p1_placement = p1_placement.replace(/\s+/g, '');
p1_placement = placement(p1_placement, 1);


//get the second player's name & placement
var p2 = prompt("Please enter the second player's name");
while (!p2) {
    p2 = prompt("The name is not valid. please enter again");
}
var p2_placement = prompt("Please enter your placement");
p2_placement = p2_placement.replace(/\s+/g, '');
p2_placement = placement(p2_placement, 2);


//display the array 
console.log(p1_gameboard);
console.log(p2_gameboard);

//result boards
var p1_result;
var p2_result;


//loop through the whole game until the game is over
// while(!gameover){
//     //check the turn
//     switch(turn){
//         case 0:
//             round1();
//             break;
//         case 1:
//             round2();
//             break;
//         default:
//             gameover = true;
//     }
// }

round1();

// ------------------ Functions ------------------
function initialize(container, p) {
    // make the grid columns and rows
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {

            // create a new div HTML element for each grid square and make it the right size
            var square = document.createElement("div");
            container.appendChild(square);

            // give each div element a unique id based on its row and column, like "s00"
            switch (p) {
                case 1:
                    square.id = 'a' + j + i;
                    break;
                case 2:
                    square.id = 'b' + j + i;
                    break;
            }


            // set each grid square's coordinates: multiples of the current row or column number
            var topPosition = j * squareSize;
            var leftPosition = i * squareSize;

            // use CSS absolute positioning to place each grid square on the page
            square.style.top = topPosition + 'px';
            square.style.left = leftPosition + 'px';
        }
    }

    return container;
}

function generateGameboard(gameBoard) {

    gameBoard = new Array(10);
    //loop to create a 2D array using 1D array
    for (var i = 0; i < gameBoard.length; i++) {
        gameBoard[i] = new Array(10);
    }

    //loop to initialized 2D array elements
    for (var i = 0; i < gameBoard.length; i++) {
        for (var j = 0; j < gameBoard[i].length; j++) {
            gameBoard[i][j] = { value: 0, type: '' };
        }
    }

    return gameBoard;
}

function placement(ar, p) {
    var split = ar.split(";");
    for (var i = 0; i < 3; i++) {

        //get the location
        var y_bgein = alpha.indexOf(split[i].charAt(2));
        var y_end = alpha.indexOf(split[i].charAt(5));
        var x_begin = split[i].charAt(3);
        var x_end = split[i].charAt(6);

        //update the game board
        if ((y_end - y_bgein) == 0) {
            //get the ship name
            var length = x_end - x_begin + 1;
            var ship;
            //determine the ship type
            switch (length) {
                case 5:
                    ship = shipNames.A;
                    break;

                case 4:
                    ship = shipNames.B;
                    break;

                case 3:
                    ship = shipNames.S;
                    break;
                default:
            }
            for (var j = x_begin; j <= x_end; j++) {
                placementUI(j, y_bgein, 1, p, ship);
            }
        }
        else if ((x_end - x_begin) == 0) {
            //get the ship name
            var length = y_end - y_bgein + 1;
            var ship;
            //determine the ship type
            switch (length) {
                case 5:
                    ship = shipNames.A;
                    break;

                case 4:
                    ship = shipNames.B;
                    break;

                case 3:
                    ship = shipNames.S;
                    break;
                default:
            }
            for (var j = y_bgein; j <= y_end; j++) {
                placementUI(x_begin, j, 1, p, ship);
            }
        }
    }

}

function placementUI(x, y, num, p, ship) {

    switch (p) {
        case 1:
            p1_gameboard[y][x].value = num;
            p1_gameboard[y][x].type = ship;
            // var element = document.getElementById('a' + y + x);
            // element.innerHTML = ship;

            break;
        case 2:
            p2_gameboard[y][x].value = num;
            p2_gameboard[y][x].type = ship;
            // var element = document.getElementById('b' + y + x);
            // element.innerHTML = ship;
            break;
        default:
            alert("Invalid update game board");
    }
}


function round1() {
    hideBoard();
    clearBoard();
    confirm("Click OK to begin " + p1 + "'s turn");
    //display our placement
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            index = p1_gameboard[j][i].value
            if (index >= 1) {
                var element = document.getElementById('b' + j + i);
                element.innerHTML = p1_gameboard[j][i].type;
                if (index == 2) {
                    element.style.background = 'red';
                }
                else if (index == 3) {
                    element.style.background = 'white';
                }
            }
        }
    }

    //display enemy's placement
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            index = p2_gameboard[j][i].value;
            if (index >= 1) {
                element = document.getElementById('a' + j + i);
                if (index == 2) {
                    element.style.background = 'red';
                }
                else if (index == 3) {
                    element.style.background = 'white';
                }
            }
        }
    }
    
}

function round2() {
    hideBoard();
    clearBoard();
    confirm("Click OK to begin " + p2 + "'s turn");
    //display our placement
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            index = p2_gameboard[j][i].value;
            if (index >= 1) {
                var element = document.getElementById('b' + j + i);
                element.innerHTML = p2_gameboard[j][i].type;
                if (index == 2) {
                    element.style.background = 'red';
                }
                else if (index == 3) {
                    element.style.background = 'white';
                }
            }
        }
    }

    //display enemy's placement
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            index = p1_gameboard[j][i].value;
            if (index >= 1) {
                element = document.getElementById('a' + j + i);
                if (index == 2) {
                    element.style.background = 'red';
                }
                else if (index == 3) {
                    element.style.background = 'white';
                }
            }
        }
    }
        
}


//clear the board between turns
function clearBoard() {
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            var grid1 = document.getElementById('a'+j+i);
            var grid2 = document.getElementById('b'+j+i);
            grid1.style.background = 'lightblue';
            grid1.innerHTML = '';

            grid2.style.background = 'lightblue';
            grid2.innerHTML = '';
        }
    }
}

function fire(e) {
    // if item clicked (e.target) is not the parent element on which the event listener was set (e.currentTarget)
    if (e.target !== e.currentTarget) {
        // extract row and column # from the HTML element's id
        var row = e.target.id.charAt(1);
        var col = e.target.id.charAt(2);
        //alert("Clicked on row " + row + ", col " + col);

        //check the round
        if (turn == 1) {
            // if player clicks a square with no ship, change the color and change square's value
            if (p1_gameboard[row][col].value == 0) {
                document.getElementById('a' + row + col).style.background = 'white';
                // set this square's value to 3 to indicate that they fired and missed
                p1_gameboard[row][col].value = 3;
                alert("You missed");

                // if player clicks a square with a ship, change the color and change square's value
            } else if (p1_gameboard[row][col].value == 1) {
                document.getElementById('a' + row + col).style.background = 'red';
                // set this square's value to 2 to indicate the ship has been hit
                p1_gameboard[row][col].value = 2;
                alert("You hit");

                var type = p1_gameboard[row][col].type;

                switch (type) {
                    case 'A':
                        hitCount.A_A++;
                        if (hitCount.A_A == 5) {
                            alert("the enemy's aircraft is sunk");
                        }
                        break;

                    case 'B':
                        hitCount.A_B++;
                        if (hitCount.A_B == 4) {
                            alert("the enemy's battle ship is sunk");
                        }
                        break;

                    case 'S':
                        hitCount.A_S++;
                        if (hitCount.A_S == 3) {
                            alert("the enemy's submarine is sunk");
                        }
                        break;
                }

                hitCount.B += 2;
                // this definitely shouldn't be hard-coded, but here it is anyway. lazy, simple solution:
                if (hitCount.B == 24) {
                    alert("All enemy battleships have been defeated! You win!");
                    gameover = true;
                    hitCount.A -= hitCount.B;
                    hitCount.B -= hitCount.A;
                    writeToLocal();
                }

                // if player clicks a square that's been previously hit, let them know
            } else if (p1_gameboard[row][col].value > 1) {
                //alert("Stop wasting your torpedos! You already fired at this location.");
            }
            window.localStorage.setItem('round',0);
        }

        if (turn == 0) {
            // if player clicks a square with no ship, change the color and change square's value
            if (p2_gameboard[row][col].value == 0) {
                document.getElementById('a' + row + col).style.background = 'white';
                // set this square's value to 3 to indicate that they fired and missed
                p2_gameboard[row][col].value = 3;
                alert("You missed");

                // if player clicks a square with a ship, change the color and change square's value
            } else if (p2_gameboard[row][col].value == 1) {
                document.getElementById('a' + row + col).style.background = 'red';
                // set this square's value to 2 to indicate the ship has been hit
                p2_gameboard[row][col].value = 2;
                alert("You hit");

                var type = p2_gameboard[row][col].type;

                switch (type) {
                    case 'A':
                        hitCount.B_A++;
                        if (hitCount.B_A == 5) {
                            alert("the enemy's aircraft is sunk");
                        }
                        break;

                    case 'B':
                        hitCount.B_B++;
                        if (hitCount.B_B == 4) {
                            alert("the enemy's battle ship is sunk");
                        }
                        break;

                    case 'S':
                        hitCount.B_S++;
                        if (hitCount.B_S == 3) {
                            alert("the enemy's submarine is sunk");
                        }
                        break;
                }
                // increment hitCount each time a ship is hit
                hitCount.A += 2;
                // this definitely shouldn't be hard-coded, but here it is anyway. lazy, simple solution:
                if (hitCount.A == 6) {
                    alert("All enemy battleships have been defeated! You win!");
                    gameover = true;
                    hitCount.A -= hitCount.B;
                    hitCount.B -= hitCount.A;
                    writeToLocal();
                }

                // if player clicks a square that's been previously hit, let them know
            } else if (p2_gameboard[row][col].value > 1) {
                //alert("Stop wasting your torpedos! You already fired at this location.");
            }
            window.localStorage.setItem('round',1);
        }
    }
    //e.stopPropagation();
    turn = window.localStorage.getItem('round');
    if(turn == 0){
        hideBoard(0);
    } 
    else if (turn == 1){
        hideBoard(1);
    }
}

function showBoard(){
    document.querySelector("link[href='blank.css']").href = "battleship.css";    
}

function hideBoard(t){
    document.querySelector("link[href='battleship.css']").href = "blank.css";
    window.setTimeout(function () {
        showBoard();
        switch(t){
            case 0:
                round1();
                break;
            case 1:
                round2();
                break;
        }
    }, 500)
}

function writeToLocal(){
    var local = window.localStorage.getItem('rank');

    if(local == null){
        var ar = {p1:hitCount.A, p2:hitCount.B};
        window.localStorage.setItem('rank', JSON.stringify(ar));
    } else{
        var ar = JSON.parse(local);
        //add two players to the record
        ar[p1] = hitCount.A;
        ar[p2] = hitCount.B;

        //sort the record
        var sortable = [];
        for(var item in ar){
            sortable.push([item,ar[item]]);
        }
        sortable.sort(function(a,b){
            return a[1] - b[1];
        });

        //get the top 10
        if(sortable.length > 10){
            sortable = sortable.substring(0, 11);
        }
        var newRecord = {};
        for (var i = sortable.length - 1; i > 0; i --){
            newRecord[sortable[i][0]] = sortable[i][1];
        }

        //write back to the local storage
        window.localStorage.setItem('rank', JSON.stringify(newRecord));
    }

    console.log(window.localStorage.getItem('rank'));
    document.querySelector("link[href='battleship.css']").href = "blank.css";
    window.setTimeout(function () {
        alert("check the console for the top 10 at local storage");
    }, 500)
}

